#from .postcrud import post_detail, PostView, like
from .contactcrud import ContactView, ContactDetail
from .auth import login, logout