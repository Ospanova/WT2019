from .auth import login, logout, Register, UserList, UserInfo
from .views import locations_view, location_view, Cinemas, CinemaView, \
    Movies, MovieView, Reviews, Tickets, TicketView, Clearer, description
